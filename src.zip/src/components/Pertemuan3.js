import React, { Component } from 'react';
import { Container, Header, Title, Content, Card, CardItem, Right, Button, Body, Icon, Text, Fab } from 'native-base';
// import { View,Text } from 'react-native';
import {ToastAndroid} from 'react-native';

export default class Pertemuan3 extends Component<>{
	render(){
		const {navigate} = this.props.navigation;
		return (
				<Container>
					<Header>
						<Body>
							<Title>Kontak</Title>
						</Body>
					</Header>
					<Content>
						<Card>
							<CardItem>
								<Icon name="person" />
								<Text>Nama Kontak</Text>
								<Text note>085068817657</Text>
								<Right>
									<Icon name="create" />
								</Right>
							</CardItem>
						</Card>
					</Content>
					<Fab
						onPress={()=>navigate('Tambah')}
						position="bottomRight"
						style={{backgroundColor:'red'}}
					>
						<Icon name="add" />
					</Fab>
				</Container>
			)
	}
}