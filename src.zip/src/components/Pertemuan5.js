import React,{Component } from 'react';
import {Container,Header,Title,Content,Button,Body,Left,Right,Icon,Text,Form,Item,Input,Label} from 'native-base';
export default class Pertemuan5 extends Component<>{

	
	render(){
		const {goBack} = this.props.navigation;
		return (
			<Container>
				<Header>
					<Left>
						
						<Button transparent onPress={()=>goBack('Home')}>
							<Icon name='arrow-back'/>
						</Button>
					</Left>
					<Body>
						<Title>Kontak</Title>
					</Body>
				</Header>
			</Container>
			)
	}
}