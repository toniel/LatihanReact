import React, { Component } from 'react';
import Pertemuan3 from './components/Pertemuan3';
import {Route} from './Route';
export default class App extends Component<> {
  render() {
    return (
    <Route/>
    );
  }
}

